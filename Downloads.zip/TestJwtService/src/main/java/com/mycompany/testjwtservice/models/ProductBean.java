/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.testjwtservice.models;


import com.mycompany.testjwtservice.config.Product;
import java.util.Collection;
import javax.inject.Named;
import javax.enterprise.context.RequestScoped;
import javax.persistence.EntityManager;
import javax.persistence.Persistence;

/**
 *
 * @author Abc
 */
@Named(value = "productBean")
@RequestScoped
public class ProductBean {

    EntityManager em;
    /**
     * Creates a new instance of ProductBean
     */
    public ProductBean() {
         em = Persistence.createEntityManagerFactory("com.mycompany_TestJwtService_war_1.0-SNAPSHOTPU").createEntityManager();
    }
    
    public Collection<Product> getProducts() { 
        int price = 5000;
         //return em.createNamedQuery("Product.findAll",Product.class).getResultList();
        return em.createQuery("SELECT p FROM Product p WHERE p.price <" + price ).getResultList();
    }
    
}
