package com.mycompany.testjwtservice.service;


import com.mycompany.testjwtservice.config.Product;
import com.mycompany.testjwtservice.models.ProductBean;
import java.util.Collection;
import javax.annotation.security.RolesAllowed;
import javax.inject.Inject;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

@Path("/example")
public class ExampleService {
  @Inject ProductBean obj;
  
    @RolesAllowed("Admin")
    @GET
    @Path("getHello")
    @Produces(MediaType.APPLICATION_JSON)
    public String getHello() {
        return "Hello World";
    }
    
    @RolesAllowed("Admin")
    @GET
    @Path("getProduct")
    @Produces(MediaType.APPLICATION_XML )
    public Collection<Product> getProduct() {
        
        return obj.getProducts();
    }

}
