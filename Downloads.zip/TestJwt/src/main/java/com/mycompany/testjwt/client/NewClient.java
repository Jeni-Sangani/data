/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.testjwt.client;

import javax.ws.rs.ClientErrorException;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.WebTarget;
import org.eclipse.microprofile.rest.client.annotation.ClientHeaderParam;
import token.GenerateToken;

/**
 * Jersey REST client generated for REST resource:ExampleService [/example]<br>
 * USAGE:
 * <pre>
 *        NewClient client = new NewClient();
 *        Object response = client.XXX(...);
 *        // do whatever with response
 *        client.close();
 * </pre>
 *
 * @author Abc
 */
@ClientHeaderParam(name = "Authorization",value = "{generateToken}")
public class NewClient {

    private WebTarget webTarget;
    private Client client;
    private static final String BASE_URI = "http://localhost:8080/TestJwtService/rest";

    public NewClient() {
        client = javax.ws.rs.client.ClientBuilder.newClient();
        webTarget = client.target(BASE_URI).path("example");
    }

    public String getHello() throws ClientErrorException {
        WebTarget resource = webTarget;
        resource = resource.path("getHello");
        return resource.request(javax.ws.rs.core.MediaType.APPLICATION_JSON).get(String.class);
    }

    
    public String generateToken(){
        String token = GenerateToken.generateJWT();
        return "Bearer "+token;
    }
    
    public void close() {
        client.close();
    }
    
}
