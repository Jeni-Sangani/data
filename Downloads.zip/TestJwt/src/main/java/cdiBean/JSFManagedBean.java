/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cdiBean;

import com.mycompany.testjwt.client.clientTest;
import com.mycompany.testjwt.config.Product;
import java.util.Collection;
import javax.inject.Named;
import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import org.eclipse.microprofile.rest.client.inject.RestClient;

/**
 *
 * @author Abc
 */
@Named(value = "jSFManagedBean")
@RequestScoped
public class JSFManagedBean {
  @RestClient @Inject clientTest obj;
    /**
     * Creates a new instance of JSFManagedBean
     */
    public JSFManagedBean() {
    }
    
    public Collection<Product> getproductdata()
    {
        Collection<Product> data;
         data = obj.getProduct();
         for(Product p : data)
         {
             System.out.print(p.getProductname() + " " + p.getDescription());
         }
         return data;
    }
    
}
